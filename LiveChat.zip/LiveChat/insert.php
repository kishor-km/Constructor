<?php 
	$uname = $_REQUEST['uname'];
	$msg = $_REQUEST['msg'];

	$conn = mysql_connect("localhost", "root", "");
	mysql_select_db('chatbox',$conn);

	$insert = "INSERT logs SET
							uname='$uname',
							msg='$msg'
							";
	mysql_query($insert);

	$select = "SELECT * FROM logs ORDER BY id DESC";
	$rs=mysql_query($select);
	$count = mysql_num_rows($rs);
	if($count>0){
		while($row = mysql_fetch_array($rs)){
			echo $row['uname'] . " : " . $row['msg'] . "<br>";
		}
	}

?>