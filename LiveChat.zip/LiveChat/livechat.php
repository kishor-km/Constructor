<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
  <title>Live Chat</title>
  <link rel="shortcut icon" type="image/png" href="images/favicon.ico">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="css/hover.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="fonts/FontAwesome.otf">
  <link rel="stylesheet" type="text/css" href="style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/popper.min.js"></script>

	<script>
	   function submitChat(){
		   if( form1.uname.value == '' || form1.msg.value == ''){
			   alert("All fields are mandatory!");
		   }

		   form1.uname.readyState = true,
		   form1.uname.style.border='none';

		   var uname = encodeURIComponent(form1.uname.value);
		   var msg = encodeURIComponent(form1.msg.value);
		   var xmlhttp = new XMLHttpRequest();

		   xmlhttp.onreadystatechange = function(){
			   if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
				   document.getElementById('chatlogs').innerHTML = xmlhttp.responseText;
			   }
		   }

		   xmlhttp.open('GET','insert.php?uname='+uname+'&msg='+msg,true);
		   xmlhttp.send();
	   }

	  $(document).ready(function(e){
		  $.ajaxSetup({cache:false});

		  setInterval(function(){$('#chatlogs').load('logs.php');},2000);
	  });

	   
	
	</script>
</head>

<body bgcolor="#F0EEEC">


<div class="container top-che">

  <div class="row">
		   <div class="col-md-10 offset-md-1">
		   
		   
		   
   <div class="row">
		   <div class="col-md-3 logo">
		    
		   </div>
		   <div class="col-md-9">
		     <h2 class="che-text">Live Chat</h2>
		   </div>
	</div>
	
	<hr>
	<div class="row">
		   <div class="col-md-12">

		   <form name="form1">

				<div class="form-group">
				<label for="uname">Enter Your Name</label>
				<input type="text" class="form-control" id="uname" placeholder="Your Name" name="uname">
				</div> 		

				<div class="form-group">
				<label for="msg">Message</label>
				<textarea type="text" class="form-control" id="msg" placeholder="Message" name="msg"></textarea>
				</div>

				<a href="#" class="btn btn-primary" onclick="submitChat()">Send</a>

			</form><br/>

			<p id="chatlogs">Loding chatlog please wait....</p>
		     
			 
		   </div>
	</div>
	


	
</div>		
</div>
	
</div>


</body>
</html>