<?php 
	$conn = mysql_connect("localhost", "root", "");
	mysql_select_db('chatbox',$conn);

	$select = "SELECT * FROM logs ORDER BY id DESC";
	$rs=mysql_query($select);
	$count = mysql_num_rows($rs);
	if($count>0){
		while($row = mysql_fetch_array($rs)){
			echo $row['uname'] . " : " . $row['msg'] . "<br>";
		}
	}

?>